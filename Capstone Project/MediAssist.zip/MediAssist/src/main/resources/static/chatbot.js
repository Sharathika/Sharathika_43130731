// chatbot.js - Floating Medical Chatbot Widget

document.addEventListener("DOMContentLoaded", function () {
    // 1. Inject HTML Structure
    const chatWidgetHTML = `
        <div id="mediBotWidget" class="chat-widget-container">
            <!-- Floating Button -->
            <button id="chatToggleBtn" class="chat-fab">
                <i class="fas fa-robot"></i>
            </button>

            <!-- Chat Popup Window -->
            <div id="chatPopup" class="chat-popup">
                <div class="chat-header">
                    <h3>MediAssist Bot</h3>
                    <div class="header-controls">
                        <div class="recording-indicator" id="recIndicator"></div>
                        <button class="lang-toggle-sm" id="langBtn">EN</button>
                        <button class="close-btn" id="closeChatBtn">&times;</button>
                    </div>
                </div>

                <div class="chat-messages" id="chatbox">
                    <div class="message bot-msg">
                        Hello! I am your AI Medical Assistant. How can I help you today?
                        <br><small style="opacity:0.7;">Try saying "I have a headache"</small>
                    </div>
                </div>

                <div class="chat-controls">
                    <button class="mic-btn" id="micBtn">
                        <i class="fas fa-microphone"></i>
                    </button>
                    <input type="text" id="chatInput" placeholder="Type or speak...">
                    <button class="send-btn" id="sendBtn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </div>
    `;

    // Append to body
    const div = document.createElement('div');
    div.innerHTML = chatWidgetHTML;
    document.body.appendChild(div);

    // 2. Logic & Event Listeners
    initChatLogic();
});

function initChatLogic() {
    const popup = document.getElementById('chatPopup');
    const toggleBtn = document.getElementById('chatToggleBtn');
    const closeBtn = document.getElementById('closeChatBtn');
    const langBtn = document.getElementById('langBtn');
    const micBtn = document.getElementById('micBtn');
    const sendBtn = document.getElementById('sendBtn');
    const chatInput = document.getElementById('chatInput');
    const chatbox = document.getElementById('chatbox');
    const recIndicator = document.getElementById('recIndicator');

    let currentLang = 'en-US';
    let recognition;
    let isRecording = false;

    // --- TOGGLE VISIBILITY ---
    toggleBtn.addEventListener('click', () => {
        popup.classList.toggle('active');
        if (popup.classList.contains('active')) {
            chatInput.focus();
        }
    });

    closeBtn.addEventListener('click', () => {
        popup.classList.remove('active');
    });

    // --- SPEECH RECOGNITION SETUP ---
    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;

        recognition.onstart = function () {
            isRecording = true;
            micBtn.classList.add('active');
            recIndicator.style.display = 'block';
            chatInput.placeholder = (currentLang === 'en-US') ? "Listening..." : "கேட்கிறது...";
        };

        recognition.onend = function () {
            isRecording = false;
            micBtn.classList.remove('active');
            recIndicator.style.display = 'none';
            chatInput.placeholder = (currentLang === 'en-US') ? "Type or speak..." : "எழுதுங்கள் அல்லது பேசுங்கள்...";
        };

        recognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            chatInput.value = transcript;
            handleSendMessage();
        };
    } else {
        console.warn("Web Speech API not supported.");
    }

    // --- BUTTON ACTIONS ---
    micBtn.addEventListener('click', () => {
        if (!recognition) return alert("Voice not supported in this browser.");
        if (isRecording) {
            recognition.stop();
        } else {
            recognition.lang = currentLang;
            recognition.start();
        }
    });

    sendBtn.addEventListener('click', handleSendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSendMessage();
    });

    langBtn.addEventListener('click', () => {
        if (currentLang === 'en-US') {
            currentLang = 'ta-IN';
            langBtn.innerText = 'TA';
            addBotMessage("வணக்கம்! நான் உங்கள் மருத்துவ உதவியாளர். உங்களுக்கு என்ன பிரச்சனை?");
        } else {
            currentLang = 'en-US';
            langBtn.innerText = 'EN';
            addBotMessage("Switched to English. How can I help?");
        }
    });

    function handleSendMessage() {
        const text = chatInput.value.trim();
        if (!text) return;

        // User Msg
        chatbox.innerHTML += `<div class="message user-msg">${text}</div>`;
        chatInput.value = '';
        chatbox.scrollTop = chatbox.scrollHeight;

        // Bot Response
        setTimeout(() => {
            let response = getMedicalResponse(text);
            addBotMessage(response);
            speakText(response);
        }, 500);
    }

    function addBotMessage(text) {
        chatbox.innerHTML += `<div class="message bot-msg">${text}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight;
    }

    function speakText(text) {
        if ('speechSynthesis' in window) {
            // Cancel any ongoing speech
            window.speechSynthesis.cancel();

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = currentLang;
            window.speechSynthesis.speak(utterance);
        }
    }

    // Mock DB
    const medicalDB = {
        'en-US': {
            'headache': "For a headache, try resting in a dark room and staying hydrated. You can take Paracetamol if needed. If it persists, consult a doctor.",
            'fever': "Monitor your temperature. Drink plenty of fluids. Take rest. If temperature exceeds 102°F, visit a doctor immediately.",
            'cold': "Drink warm water and take steam inhalation. Vitamin C helps. Rest well.",
            'stomach pain': "Avoid heavy meals. Drink weak tea or warm water. If pain is severe, please see a doctor.",
            'default': "I am not sure about that. Please consult a doctor for accurate advice."
        },
        'ta-IN': {
            'தலைவலி': "தலைவலிக்கு, இருண்ட அறையில் ஓய்வெடுக்கவும். தண்ணீர் அதிகம் குடிக்கவும். தேவைப்பட்டால் பாராசிட்டமால் எடுத்துக் கொள்ளலாம்.",
            'காய்ச்சல்': "உங்கள் வெப்பநிலையை கண்காணிக்கவும். நிறைய தண்ணீர் குடிக்கவும். ஓய்வெடுக்கவும். காய்ச்சல் அதிகமானால் மருத்துவரை அணுகவும்.",
            'சளி': "வெதுவெதுப்பான நீர் குடிக்கவும். ஆவி பிடிப்பது நல்லது. நன்றாக ஓய்வெடுக்கவும்.",
            'வயிற்று வலி': "கனமான உணவுகளை தவிர்க்கவும். வெதுவெதுப்பான நீர் குடிக்கவும்.",
            'default': "எனக்கு அது பற்றி தெரியவில்லை. தயவுசெய்து மருத்துவரை அணுகவும்."
        }
    };

    function getMedicalResponse(query) {
        const db = medicalDB[currentLang];
        const lowerQuery = query.toLowerCase();
        for (let key in db) {
            if (lowerQuery.includes(key) && key !== 'default') {
                return db[key];
            }
        }
        return db['default'];
    }
}
