package com.example.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.example.demo.model.User;

public class UserDAO {

    private String url = "jdbc:mysql://localhost:3306/mediassist_db";
    private String username = "root";
    private String password = "root";

    // REGISTER USER
    public boolean registerUser(User user) {
        String sql = "INSERT INTO users(name, email, password, phone) VALUES (?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getPhone());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("DEBUG: DB Register Error: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // LOGIN USER
    public User login(String email, String pass) {
        String sql = "SELECT * FROM users WHERE email=? AND password=?";

        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                return user;
            }

        } catch (Exception e) {
            System.out.println("DEBUG: DB Login Error: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // GET ALL USERS (For Admin Dashboard)
    public java.util.List<User> getAllUsers() {
        java.util.List<User> users = new java.util.ArrayList<>();
        String sql = "SELECT * FROM users";

        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                users.add(user);
            }
        } catch (Exception e) {
            System.out.println("DEBUG: DB GetAllUsers Error: " + e.getMessage());
            e.printStackTrace();
        }
        return users;
    }
}