package com.example.demo.controller;



import java.util.Collections;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserDAO;
import com.example.demo.model.User;

@RestController
public class AuthController {

    UserDAO userDAO = new UserDAO();
    com.example.demo.dao.AdminDAO adminDAO = new com.example.demo.dao.AdminDAO();

    // REGISTER
    @PostMapping("/register")
    public ResponseEntity<?> register(@ModelAttribute User user) {
        boolean status = userDAO.registerUser(user);

        if (status) {
            return ResponseEntity.ok().body(Collections.singletonMap("status", "success"));
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonMap("status", "failure"));
        }
    }

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(@ModelAttribute User user) {
        System.out.println("DEBUG: Login request received for email: " + user.getEmail());

        // 1. Try User Login
        User loggedUser = userDAO.login(user.getEmail(), user.getPassword());
        
        java.util.Map<String, String> response = new java.util.HashMap<>();

        if (loggedUser != null) {
            response.put("status", "success");
            response.put("role", "user");
            return ResponseEntity.ok().body(response);
        }
        
        // 2. Try Admin Login (if user not found)
        boolean isAdmin = adminDAO.checkAdmin(user.getEmail(), user.getPassword());
        if (isAdmin) {
            response.put("status", "success");
            response.put("role", "admin");
            return ResponseEntity.ok().body(response);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Collections.singletonMap("status", "failure"));
    }

    // GET ALL USERS API
    @org.springframework.web.bind.annotation.GetMapping("/api/admin/users")
    public ResponseEntity<?> getAllUsers() {
        java.util.List<User> users = userDAO.getAllUsers();
        return ResponseEntity.ok(users);
    }
}


