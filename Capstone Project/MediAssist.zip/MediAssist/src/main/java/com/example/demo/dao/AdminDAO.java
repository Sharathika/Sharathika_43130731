package com.example.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDAO {

    private String url = "jdbc:mysql://localhost:3306/mediassist_db";
    private String username = "root";
    private String password = "root";

    // CHECK ADMIN CREDENTIALS
    public boolean checkAdmin(String email, String pass) {
        String sql = "SELECT * FROM admins WHERE email=? AND password=?";
        
        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();
            return rs.next(); // Returns true if a record is found

        } catch (Exception e) {
            System.out.println("DEBUG: Admin Login Error: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}
